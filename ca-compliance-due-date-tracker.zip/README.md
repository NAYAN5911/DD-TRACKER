# CA Compliance Due-Date Tracker

A lightweight compliance deadline tracker for CA practices and finance teams.

## Features
- Add, edit, complete, reopen and delete compliance records.
- Client, compliance category, due date and notes.
- Automatic overdue / due today / due soon / upcoming classification.
- Dashboard counters, search and filters.
- Excel export.
- Browser local storage; no backend required.

## Run locally
Open `index.html` in a modern browser. Internet access is required for the SheetJS library used for Excel export.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `styles.css`, `app.js` and `README.md` to the repository root.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.

## Data and reminders
Records are stored in the browser's local storage on the device/browser where they were entered. They do not automatically sync across devices. Export Excel backups regularly. This version displays due-date status when opened; it does not send email, SMS, or background push notifications.

This tool is a tracking aid. Verify statutory due dates against current official notifications before relying on them.
