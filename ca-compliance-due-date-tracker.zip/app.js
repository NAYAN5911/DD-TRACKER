const $=s=>document.querySelector(s);
const KEY="caComplianceTracker_v1";
let records=JSON.parse(localStorage.getItem(KEY)||"[]");
const today=()=>{const d=new Date();d.setHours(0,0,0,0);return d};
const dayDiff=date=>Math.round((new Date(date+"T00:00:00")-today())/86400000);
const status=r=>{if(r.completed)return"Completed";const n=dayDiff(r.dueDate);return n<0?"Overdue":n===0?"DueToday":n<=7?"DueSoon":"Upcoming"};
const label=s=>({"DueToday":"Due Today","DueSoon":"Due Soon"}[s]||s);
const save=()=>{localStorage.setItem(KEY,JSON.stringify(records));render()};
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function render(){
 const counts={Overdue:0,DueToday:0,DueSoon:0,Upcoming:0,Completed:0};records.forEach(r=>counts[status(r)]++);
 $("#metrics").innerHTML=[["Total records",records.length,"All tracked work"],["Overdue",counts.Overdue,"Requires attention"],["Due today",counts.DueToday,"Deadline is today"],["Due this week",counts.DueSoon,"Next 7 days"],["Completed",counts.Completed,"Marked complete"]].map((x,i)=>`<div class="metric"><span>${x[0]}</span><strong>${x[1]}</strong><em>${x[2]}</em></div>`).join("");
 const q=$("#search").value.toLowerCase(),sf=$("#statusFilter").value,tf=$("#typeFilter").value;
 const list=records.filter(r=>(r.client+" "+r.task+" "+(r.notes||"")).toLowerCase().includes(q)&&(sf==="All"||label(status(r))===sf||status(r)===sf)&&(tf==="All"||r.category===tf)).sort((a,b)=>status(a)==="Completed"?1:status(b)==="Completed"?-1:a.dueDate.localeCompare(b.dueDate));
 $("#rows").innerHTML=list.map(r=>{const s=status(r),n=dayDiff(r.dueDate),remaining=r.completed?"—":n<0?`${Math.abs(n)} day(s) overdue`:n===0?"Due today":`${n} day(s) left`;return `<tr><td><span class="client">${esc(r.client)}</span><span class="sub">${esc(r.notes||"")}</span></td><td><b>${esc(r.task)}</b></td><td>${esc(r.category)}</td><td>${new Date(r.dueDate+"T00:00:00").toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}</td><td>${remaining}</td><td><span class="pill ${s}">${label(s)}</span></td><td class="actions">${r.completed?`<button data-action="undo" data-id="${r.id}">Reopen</button>`:`<button data-action="done" data-id="${r.id}">Complete</button>`}<button data-action="edit" data-id="${r.id}">Edit</button><button data-action="delete" data-id="${r.id}">Delete</button></td></tr>`}).join("");
 $("#empty").hidden=list.length>0;
}
function openForm(r){$("#taskForm").reset();$("#editId").value=r?.id||"";$("#formTitle").textContent=r?"Edit compliance":"Add compliance";if(r){$("#client").value=r.client;$("#task").value=r.task;$("#category").value=r.category;$("#dueDate").value=r.dueDate;$("#notes").value=r.notes||""}$("#formDialog").showModal()}
$("#addBtn").onclick=()=>openForm();$("#closeBtn").onclick=$("#cancelBtn").onclick=()=>$("#formDialog").close();
$("#taskForm").onsubmit=e=>{e.preventDefault();const id=$("#editId").value;const item={id:id||crypto.randomUUID(),client:$("#client").value.trim(),task:$("#task").value.trim(),category:$("#category").value,dueDate:$("#dueDate").value,notes:$("#notes").value,completed:id?(records.find(x=>x.id===id)?.completed||false):false};if(id)records=records.map(x=>x.id===id?item:x);else records.push(item);$("#formDialog").close();save()};
$("#rows").onclick=e=>{const b=e.target.closest("button[data-action]");if(!b)return;const {action,id}=b.dataset,r=records.find(x=>x.id===id);if(action==="done")r.completed=true;if(action==="undo")r.completed=false;if(action==="edit")return openForm(r);if(action==="delete"&&confirm("Delete this compliance record?"))records=records.filter(x=>x.id!==id);save()};
["search","statusFilter","typeFilter"].forEach(id=>$("#"+id).addEventListener("input",render));
$("#exportBtn").onclick=()=>{if(!records.length){alert("No records to export.");return}const rows=records.map(r=>({Client:r.client,Compliance:r.task,Category:r.category,"Due Date":r.dueDate,Status:label(status(r)),Completed:r.completed?"Yes":"No",Notes:r.notes||""}));const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(rows),"Compliance Tracker");XLSX.writeFile(wb,"CA_Compliance_Tracker.xlsx")};
render();